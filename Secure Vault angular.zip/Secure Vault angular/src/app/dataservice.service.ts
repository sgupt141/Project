import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {


  constructor(private http: HttpClient) { }

  public tempUser:User;
  public userDb:any[]=[];
  public flag:boolean=false;
  public passString:string="";

 
  getUsers()
  {
    this.http.get<User[]>('http://localhost:3000/user').subscribe(resp=>{
      for(const i of(resp as any)){
        this.userDb.push({
          id:i.id,
          email:i.email,
          password:i.password,
          name:i.name,
          phoneNo:i.phoneNo,
          city:i.city,
          state:i.state
        })
      }
    });
  }

  addUsers(User:User)
  {
    return this.http.post('http://localhost:3000/user',User);
  }

  updateUsers(id:any,User:User){
    return this.http.put('http://localhost:3000/user/'+id,User);
  }
  getUserById(id:any)
  {
    return this.http.get('http://localhost:3000/user/'+id);
  }
}
