import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DataserviceService } from '../dataservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userSer:DataserviceService, private router:Router) { }

  ngOnInit(): void {
    this.userSer.getUsers();
    console.log(this.userSer.userDb);
  }
  custlogin = new FormGroup({
    email: new FormControl('', [Validators.email,Validators.required]),
    pass: new FormControl('',[Validators.required])
  });

  login() {
  
    let email = this.custlogin.get('email').value;
    let pass = this.custlogin.get('pass').value;
    
    for(let i=0;i<this.userSer.userDb.length;i++) {
      if (this.userSer.userDb[i].email == email&&this.userSer.userDb[i].password==pass){     
        console.log(this.userSer.userDb[i].email);
        this.userSer.tempUser=this.userSer.userDb[i];
        this.userSer.flag=true;
        break;
      }
    }
    if (this.userSer.flag) {
        this.router.navigateByUrl("/userHome");
        alert("Successfull login"+this.userSer.tempUser.name);     
    }
    else {
      this.router.navigateByUrl("/login");
      alert("Invalid username and password");
    }
  }

}
