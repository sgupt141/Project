import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { Router } from '@angular/router';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private userSer:DataserviceService, private router:Router) { }

  ngOnInit(): void {
    this.userSer.getUsers();
    console.log(this.userSer.userDb);
  }

  signups=new FormGroup({
    name: new FormControl(''),
    phoneNumber: new FormControl(''),
    email: new FormControl('', [Validators.email]),
    password: new FormControl('')
  });

  signup(){
    let name = this.signups.get('name').value;
        let phoneNo = this.signups.get('phoneNumber').value;
        let emails = this.signups.get('email').value;
        let pass= this.signups.get('password').value;
        let l=this.userSer.userDb.length;
        let id=this.userSer.userDb[l-1].id+1;
        for(let i=0;i<this.userSer.userDb.length;i++){
            if(emails==this.userSer.userDb[i].email){
                document.getElementById("exists").innerHTML="User with same email already existed";
                return;
            }
        }
        let temp:User=new User(id,emails,pass,name,phoneNo,"NONE","NONE");
        this.userSer.addUsers(temp).subscribe(data=>{console.log(data)}); 
        this.router.navigateByUrl("/login"); 
        alert("Successfully registered"+id+" "+emails);
        
  }
}
