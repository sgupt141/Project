export class User
{
    id:BigInteger;
    email:string;
    password:string;
    name:string;
    phoneNo:string;
    city:string;
    state:string;

    constructor(id:BigInteger,email:string,password:string,name:string,phoneNo:string,city:string,state:string)
    {
        this.id=id;
        this.email=email;
        this.password=password;
        this.name=name;
        this.city=city;
        this.phoneNo=phoneNo;
        this.state=state;
    }
}