import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { Router } from '@angular/router';
import { User } from '../user';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {

  
  constructor(private userSer:DataserviceService, private router:Router) { }
  currentUser:User=this.userSer.tempUser;
  
  ngOnInit(): void {
  }
  logout(){
    this.userSer.tempUser=null;
    this.currentUser=this.userSer.tempUser;
   }

   getSite = new FormGroup({
    site: new FormControl('', [Validators.required])
  });

  getPassword() {
  
    let inputSite = this.getSite.get('inputSite').value;
    
  }
}
