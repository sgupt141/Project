import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-updateuser',
  templateUrl: './updateuser.component.html',
  styleUrls: ['./updateuser.component.css']
})
export class UpdateuserComponent implements OnInit {

  constructor(private userSer:DataserviceService, private router:Router) { }
  currentUser:User=this.userSer.tempUser;
  flagName:boolean=false;
  flagPhoneNo:boolean=false;
  flagCity:boolean=false;
  flagState:boolean=false;
  flagPassword:boolean=false;

  ngOnInit(): void {
  }

  changeName(){
    this.flagName=true;
    this.flagPhoneNo=false;
    this.flagCity=false;
    this.flagState=false;
    this.flagPassword=false;
    return;
  }
  changePhoneNo(){
    this.flagName=false;
    this.flagPhoneNo=true;
    this.flagCity=false;
    this.flagState=false;
    this.flagPassword=false;
    return;
  }
  changeCity(){
    this.flagName=false;
    this.flagPhoneNo=false;
    this.flagCity=true;
    this.flagState=false;
    this.flagPassword=false;
    return;
  }
  changeState(){
    this.flagName=false;
    this.flagPhoneNo=false;
    this.flagCity=false;
    this.flagState=true;
    this.flagPassword=false;
    return;
  }
  changePassword(){
    this.flagName=false;
    this.flagPhoneNo=false;
    this.flagCity=false;
    this.flagState=false;
    this.flagPassword=true;
    return;
  }
  updateName(){
    this.flagName=false;
    return;
  }
  updatePhoneNo(){
    this.flagPhoneNo=false;
    return;
    
  }
  updateCity(){
    this.flagCity=false;
    return;
  }
  updateState(){
    this.flagState=false;
    return;
  }
  updatePassword(){
    var pswd=(<HTMLInputElement>document.getElementById("oldPassword")).value;
    var newPswd=(<HTMLInputElement>document.getElementById("newPassword")).value;
    var newPswd2=(<HTMLInputElement>document.getElementById("newPassword2")).value;
    this.currentUser.password=newPswd;
    this.userSer.updateUsers(this.currentUser.id,this.currentUser).subscribe();
    this.flagPassword=false;
    return;
  }
}
