package com.cg.exception;

public class ExeException extends Exception{

	public ExeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public ExeException(String arg0) {
		super(arg0);
	}	
}
