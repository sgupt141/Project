package com.cg.dao;

import com.cg.dto.Dto;

public class DaoImpl implements Dao{
	
	Dto user = new Dto();
	@Override
	public void addDetails(String username, Dto dto) {
		
		StaticDb.hashList.put(username, dto);
		
	}

	@Override
	public boolean isValidUser(String username, String password) {
		if(StaticDb.hashList.containsKey(username))
		{
			user = StaticDb.hashList.get(username);
			if(user.getPassword().equals(password))
				return true;
			else
				return false;
		}
		else
			return false;
	}

	@Override
	public Dto updateNewName(Dto dto) {
		// TODO Auto-generated method stub
		
		return null;
	}
	
}
