package com.cg.dao;

import com.cg.dto.Dto;

public interface Dao {

	public void addDetails(String username, Dto dto);
	public boolean isValidUser(String username, String password);
	public Dto updateNewName(Dto dto);
}
