package com.cg.dao;

import java.util.HashMap;

import com.cg.dto.Dto;

public class StaticDb {

	public static HashMap<String, Dto> hashList = new HashMap<>();
	public static HashMap<String,String> passList = new HashMap<>();
	
	
	static
	{
		hashList.put("sumitgupta@gmail.com", new Dto("Sumit", "sumitgupta@gmail.com", "sgupt141", "9897768985", "Hello@123"));
	}


	public static HashMap<String, Dto> getHashList() {
		return hashList;
	}


	public static void setHashList(HashMap<String, Dto> hashList) {
		StaticDb.hashList = hashList;
	}


	public static HashMap<String, String> getPassList() {
		return passList;
	}


	public static void setPassList(HashMap<String, String> passList) {
		StaticDb.passList = passList;
	}
	
	
}
