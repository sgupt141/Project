package com.cg.des;
import java.security.Key;

import java.security.KeyPair;
import java.util.Arrays;
public class Main {
		public String getPassword(String password) {
		KeyPair keyPair = RSAKeyPair.keyPairRSA();
		Key publicKey = keyPair.getPublic();
		Key privateKey = keyPair.getPrivate();
		byte[] encrypted = RSAEncryptDecrypt.encrypt(password, privateKey);
		return new String(encrypted);
		}
}

/*
System.out.println("Decrypt Start");
byte[] decrypted = RSAEncryptDecrypt.decrypt(encrypted, publicKey);
System.out.println("Decrypted: " + new String(decrypted));
System.out.println("Decrypted matches Original: " + Arrays.equals(decrypted, password.getBytes()));
System.out.println("Decrypt End");
*/