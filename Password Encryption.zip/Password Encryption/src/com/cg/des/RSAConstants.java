package com.cg.des;
public final class RSAConstants {
	private RSAConstants() {
	}
	public static final String ALGORITHM = "RSA";
	public static final int ALGORITHM_BITS = 512;
}