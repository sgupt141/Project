package com.cg.service;

import com.cg.dto.Dto;

public interface Service {
	
	public Dto addDetails(String username, Dto dto);
	public boolean isValidUser(String username, String password);
	public Dto updateName(String newName);
	public Dto updateUserName(String newUserName);
	public Dto updateMobileNo(String newNumber);
	public Dto updatePassword(String newPassword, String oldPassWord);
	
}
