package com.cg.service;

import com.cg.dao.DaoImpl;
import com.cg.dao.StaticDb;
import com.cg.dto.Dto;

public class ServiceImpl implements Service {
	
	DaoImpl dao= new DaoImpl();
	Dto dto;
	
	@Override
	public Dto addDetails(String username, Dto dto) {
		
//		String name=dto.getName();
//		String email= dto.getEmail();
//		String userName= dto.getUsername();
//		String phoneNo= dto.getPhoneNo();
//		String password = dto.getPassword();
		
		dao.addDetails(username, dto);
		return null;
	}

	@Override
	public boolean isValidUser(String username, String password) {
		return dao.isValidUser(username, password);
	}

	@Override
	public Dto updateName(String newName) { 
		dto.setName(newName);
		return dao.updateNewName(dto);
	}

	@Override
	public Dto updateUserName(String newUserName) {
		// TODO Auto-generated method stub
		dto.setUsername(newUserName);
		return null;
		
	}

	@Override
	public Dto updateMobileNo(String newNumber) {
		// TODO Auto-generated method stub
		dto.setPhoneNo(newNumber);
		return null;
	}

	@Override
	public Dto updatePassword(String newPassword, String oldPassWord) {
		// TODO Auto-generated method stub
		if(dto.getPassword().equals(oldPassWord))
		{
			dto.setPassword(newPassword);
		}
		else
			System.out.println("Invalid old password./n");
		return null;
	}

	
}
