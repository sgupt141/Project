package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.exception.ExeException;

public class Validation {

	public void isNameValid(String name){
		String regex = "^[A-Za-z]*$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(name);
		
		
	}

	public boolean isEmailValid(String email){
		String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+(?:\\.[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(email);
			if(matcher != null)
				return true;
			else
				return false;
	}

	public boolean isPasswordValid(String password)throws ExeException{
		String regex = "((?=.*[a-z])(?=.*d)(?=.*[@#$%])(?=.*[A-Z]).{6,16})";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(password);
		if(matcher != null)
			return true;
		else
			return false;

	}
	
	public void isPhoneNoValid(String num)throws ExeException{
//		String regex = "[6-9][0-9]{9}";
//		Pattern pattern = Pattern.compile(regex);
//		Matcher matcher = pattern.matcher(num);
		if(num.length()<10)
			throw new ExeException("sndejdhjeejnje \n");
			
			

	}
	
	public boolean isUserNameValid(String userName){
		String regex = "^[a-z0-9_]*{9}$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(userName);
		if(matcher != null)
			return true;
		else
			return false;

	}
	
}
