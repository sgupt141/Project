package com.cg.main;

import java.util.Scanner;

import com.cg.dao.StaticDb;
import com.cg.des.Main;
import com.cg.dto.Dto;
import com.cg.exception.ExeException;
import com.cg.service.ServiceImpl;
import com.cg.service.Validation;

public class MainTest {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ServiceImpl obj= new ServiceImpl();
		Validation val = new Validation();
		Main mainObj = new Main();
		
		while(true) 
		{
			System.out.println("1. Sign Up\n"
				+ "2. Login\n"	
				+ "3. Exit\n");
			int choice = scan.nextInt();
			
			switch(choice)
			{
			case 1: System.out.println("Enter your name: \n");
					String name = scan.next();
				
					System.out.println("Enter your email: \n");
					String mail= scan.next();			
					System.out.println("Enter your username: \n");
					String userName= scan.next();
					System.out.println("Enter your Phone number: \n");
					String phoneNo = scan.next();
//					try 
//					{	
//						val.isPhoneNoValid(phoneNo);	
//					} 
//					catch (ExeException e) {
//						System.out.print(e.getMessage()); 
//					}
					System.out.println("Enter your Password: \n");
					String pass= scan.next();
					
										
					obj.addDetails(mail,new Dto(name, mail, userName, phoneNo, pass));
					System.out.println(StaticDb.hashList);
					break;
					
			case 2: System.out.println("Enter your email: \n");
					String email= scan.next();
					System.out.println("Enter your password\n");
					String password= scan.next();
					if(obj.isValidUser(email, password))
						System.out.println("Login successful\n");
					else
					{
						System.out.println("Invalid user\n");
						break;
					}
					boolean flag=true;
					while(flag) {
					System.out.println("1. To get your site password:\n"	
							+ "2. Logout\n");
					int op=scan.nextInt();
					switch(op){
						case 1: System.out.println("Enter site name to get your password: \n");
								String siteName = scan.next();
						
								String sitePassword = mainObj.getPassword(siteName);
						/* StaticDb.passList.put(siteName, sitePassword); */
								break;
							
//						case 2: System.out.println("1. To change your Name:\n"
//								+ "2. To change your User Name:\n"	
//								+ "3. To change your password:\n"
//								+ "4. To change your Mobile Number:\n");
//								int option=scan.nextInt();
//								switch(option) {
//								case 1: System.out.println("Enter your name:\n");
//										String newName = scan.next();
//										obj.updateName(newName);
//										break;
//								}
//						break;
						case 2: flag=false;
								break;
					 }
					}
					break;
			case 3: System.exit(0);
			}		
		}
	}
}
