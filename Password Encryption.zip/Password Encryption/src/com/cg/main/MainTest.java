package com.cg.main;

import java.util.Scanner;

import com.cg.dao.StaticDb;
import com.cg.des.Main;
import com.cg.dto.Dto;
import com.cg.exception.ExeException;
import com.cg.service.ServiceImpl;
import com.cg.service.Validation;

public class MainTest {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ServiceImpl obj= new ServiceImpl();
		Validation val = new Validation();
		Main mainObj = new Main();
		
		while(true) 
		{
			System.out.println("1. Sign Up\n"
				+ "2. Login\n"	
				+ "3. Exit\n");
			int choice = scan.nextInt();
			
			switch(choice)
			{
			case 1: System.out.println("Enter your name: \n");
					String name = scan.next();
				
					System.out.println("Enter your email: \n");
					String mail= scan.next();			
					System.out.println("Enter your username: \n");
					String userName= scan.next();
					System.out.println("Enter your Phone number: \n");
					String phoneNo = scan.next();
					System.out.println("Enter your Password: \n");
					String pass= scan.next();
					
										
					obj.addDetails(mail,new Dto(name, mail, userName, phoneNo, pass));
					System.out.println(StaticDb.hashList);
					break;
					
			case 2: System.out.println("Enter your email: \n");
					String email= scan.next();
					System.out.println("Enter your password\n");
					String password= scan.next();
					if(obj.isValidUser(email, password))
						System.out.println("Login successful\n");
					else
					{
						System.out.println("Invalid user\n");
						break;
					}
					boolean flag=true;
					while(flag) {
					System.out.println("1. To get your site password:\n"	
							+ "2. Logout\n");
					int op=scan.nextInt();
					switch(op){
						case 1: System.out.println("Enter site name to get your password: \n");
								String siteName = scan.next();
								if(StaticDb.passList.containsKey(siteName)){
									System.out.println(StaticDb.passList.get(siteName));
								}
								else{
									String sitePassword = mainObj.getPassword(siteName);
									StaticDb.passList.put(siteName, sitePassword.substring(0,10));
									System.out.println(StaticDb.passList.get(siteName));
								}
								break;
						case 2: flag=false;
								break;
					 }
					}
					break;
			case 3: System.exit(0);
			}		
		}
	}
}
